from PythonScratchApiWrapper import psaw, PSAWExceps
print("Version: 0.31")